//
//  Gobi.h
//  Gobi
//
//  Created by Sergii Avilov on 1/28/19.
//  Copyright © 2019 Gobitech. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GobiSDK.
FOUNDATION_EXPORT double GobiSDKVersionNumber;

//! Project version string for GobiSDK.
FOUNDATION_EXPORT const unsigned char GobiSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GobiSDK/PublicHeader.h>


